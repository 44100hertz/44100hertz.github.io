use <./brooch.scad>;

/* [Brooch] */
pegx = 6;     // [-10:10]
pegy = 0.5;    // [-10:0.5:10]
pegrot = 135;  // [-180:180]

bsize=20;
ls = 30; // logo size

color("white") {
    difference() {
    translate([0,0,0]) linear_extrude(4.5) offset(1.2) resize([ls,ls]) rotate([0,0,180])
        import("ACP1.svg", center=true);
        rotate([0,0,pegrot]) translate([pegx, pegy, -0.01]) broochCutout(size=bsize);
    }
    translate([-8,20,0]) broochPegs(size=bsize);
    translate([8,20,0]) broochPegs(size=bsize);
}

color("red") {
    difference() {
    translate([0,0,4.5]) linear_extrude(1) resize([ls,ls]) rotate([0,0,180])
        import("ACP1.svg", center=true);
        rotate([0,0,pegrot]) translate([pegx, pegy, -0.01]) broochCutout(size=20);
    }
}
