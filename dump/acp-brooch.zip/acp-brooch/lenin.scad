use <./brooch.scad>;

/* [Brooch] */
pegx = 0;     // [-10:10]
pegy = -3;    // [-10:0.5:10]
pegrot = 0;  // [-180:180]

/* [Star] */
pts = 5;
ri = 5;       // [5:0.25:10]
spokerat = 13/5;
ro = ri*spokerat;
stardepth = 5;

ls = 30; // logo size

module place() {
     translate([-22,-20]) scale(0.4) children();
}

color("white") {
    translate([0,31,0]) broochPegs(size=20);
    translate([0,25,0]) broochPegs(size=20);
    difference() {
    translate([0,0,0]) linear_extrude(4.5) rotate([0,0,180])
        place() import("lenin-white.svg");
        rotate([0,0,pegrot]) translate([pegx, pegy, -0.01]) broochCutout(size=20);
    }
}

color("black") {
    
    difference() {
    translate([0,0,4]) linear_extrude(1) rotate([0,0,180])
        place() import("lenin-black.svg");
        rotate([0,0,pegrot]) translate([pegx, pegy, -0.01]) broochCutout(size=20);
    }
}

