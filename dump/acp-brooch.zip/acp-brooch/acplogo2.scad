use <./brooch.scad>;

/* [Brooch] */
pegx = 0;     // [-20:0.5:10]
pegy = -3;    // [-10:0.5:10]
pegrot = 0;  // [-180:180]

s = 0.25;
bsize = 32;

color("white") {
    difference() {
    linear_extrude(4.5) {
        translate([-22,-12]) offset(1.2, $fn=17) square([43,24]);
    }
        rotate([0,0,pegrot]) translate([pegx, pegy, -0.01]) broochCutout(size=bsize);
    }
    
    translate([-10,17,0]) broochPegs(size=bsize);
    translate([10,17,0]) broochPegs(size=bsize);
}

color("red") {
    difference() {
    translate([0,0,4.3]) linear_extrude(1.2) scale(s) rotate([0,0,180])
        import("ACP2.svg", center=true);
        rotate([0,0,pegrot]) translate([pegx, pegy, -0.01]) broochCutout(size=bsize);
    }
}
