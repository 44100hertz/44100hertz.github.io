module pinSlot() {
    polygon([
        [-0.5,2],
        [0.5,2],
        [1,-2],
        [-1,-2],
    ]);
}

linear_extrude(3)
difference() {
    square(6, center=true);
    pinSlot();
}