function pegspacing(size) =
    size == 20 ? 7 :
    size == 25 ? 8 :
    size == 32 ? 12 :
    9;

function pegcount(size) =
    size == size > 32 ? 3 : 2;
    
function pegmargin(size) =
    size == 20 ? 6+pegr :
    size == 25 ? 6.5+pegr :
    size == 32 ? 10+pegr :
    10+pegr;

pegr = 1.1;//3/64*25.4;

module broochCutout(size, pegdepth=1, pegl=2, linewidth=0.43, xytol=0.2) {
    lw = linewidth;
    spacing = pegspacing(size);
    count = pegcount(size);
    
    bracketsize = [
        (count-1) * spacing + pegmargin(size)*2,
        6.0,
    ];
    
    difference() {
        union() {
            linear_extrude(pegdepth+1)
                square(bracketsize, center=true);
            linear_extrude(pegl+pegdepth+1)
                union() for (i=[0:count-1])
                translate([(i-count/2+0.5)*spacing, 0, 0])
                circle(r=pegr+xytol, $fn=32);
            }
        linear_extrude(pegdepth+1) union() for (i=[0:count-1])
            translate([(i-count/2+0.5)*spacing, 0, 0])
            difference() {
                circle(r=pegr+lw+xytol, $fn=32);
                circle(r=pegr+xytol, $fn=32);
                square([bracketsize.x, 1], center=true);
            }
        linear_extrude(0.3) square([bracketsize.x-8,3], center=true);
    }
}

module broochPegs(size, pegdepth=1, pegl=2, linewidth=0.43) {
    lw = linewidth;
    spacing = pegspacing(size);
    count = pegcount(size);
    
    bracketsize = [
        (count-1) * spacing + pegr*4,
        5.0,
    ];
    
    linear_extrude(pegdepth) square(bracketsize, center=true);
    linear_extrude(pegl+pegdepth) union() for (i=[0:count-1])
        translate([(i-count/2+0.5)*spacing, 0, 0])
        circle(r=pegr, $fn=32);
}

broochPegs(size=20);