use <./brooch.scad>;

/* [Brooch] */
pegx = 0;     // [-10:10]
pegy = 2;    // [-10:10]
pegrot = 36;  // [-180:180]

/* [Star] */
pts = 5;
ri = 7;       // [5:0.25:10]
spokerat = 13/5;
ro = ri*spokerat;
stardepth = 5;

lw = 0.46; // line width

function star2d (pts=pts, ri=ri, ro=ro) = [
    for (i=[0:pts*2-1])
            let (r=i%2==0 ? ri : ro)
            let (a=i/pts/2*360)
            [sin(a)*r, cos(a)*r],
];

module star(pts=pts, ri=ri, ro=ro, d=stardepth) {
    n = pts*2;
    base = [for (p=star2d(pts, ri, ro)) [p.x, p.y, 0]];
    polyhedron(
        concat([[0, 0, d]], base, [[0, 0, 0]]),
        concat(
            [for (i=[0:n-1]) [0, 1+i, 1+(i+1)%n]],
            [for (i=[0:n-1]) [n+1, 1+(i+1)%n, 1+i]],
        ));
}

color("red") {
    translate([0,15,0]) broochPegs(size=20);
    translate([0,21,0]) broochPegs(size=20);
    difference() {
        linear_extrude(3) polygon(star2d());
        rotate([0,0,pegrot]) translate([pegx, pegy, -0.01]) broochCutout(size=20);
    }
    translate([0, 0, 3]) star();
}